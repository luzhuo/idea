package com.lz.test;


import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lz.dao.IBookDao;
import com.lz.entity.BookBean;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class HibernateTest {
	
	@Resource(name="bookDao")
	private IBookDao bookDao;

		@Test
		public void test2() throws Exception {
			BookBean book = new BookBean();
			book.setAuthor("我");
			List<BookBean> find = bookDao.Find(book );
			for (BookBean bookBean : find) {
				System.out.println(bookBean.getTitle());
			}
			
		}
	}


