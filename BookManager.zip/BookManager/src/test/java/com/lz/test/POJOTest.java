package com.lz.test;

import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class POJOTest {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		SessionFactory fac=(SessionFactory) ac.getBean("sessionFactory");
		System.out.println(fac.openSession());
	}
	
	

}
