package com.lz.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.lz.entity.BookBean;
import com.lz.service.BookService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@Controller("findAction")
@Scope("prototype")
public class FindAction extends ActionSupport implements ModelDriven<BookBean>, SessionAware, RequestAware {

	private static final long serialVersionUID = 6824212890470989868L;
	private Map<String, Object> session;
	private Map<String, Object> request;
	private BookBean book = new BookBean();
	@Resource(name = "bookService")
	private BookService bookServ;

	
	public String tofind(){
		return "success";
	}
	
	public String find(){
		try {
			System.out.println(book.getAuthor()+"   "+book.getTitle()+"  "+book.getPress());
			List<BookBean> bookList = bookServ.find(book);
			session.put("bookList", bookList);
			System.out.println(bookList.size());
		} catch (Exception e) {
			System.out.println("出错啦");
			e.printStackTrace();
		}
		return "success";
	}
	@Override
	public void setRequest(Map<String, Object> request) {
		this.request = request;

	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	@Override
	public BookBean getModel() {
		
		return book;
	}

}
