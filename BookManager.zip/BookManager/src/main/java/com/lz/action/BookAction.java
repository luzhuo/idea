package com.lz.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.lz.domian.PageBean;
import com.lz.entity.BookBean;
import com.lz.service.BookService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@Controller("bookAction")
@Scope("prototype")
public class BookAction extends ActionSupport implements ModelDriven<BookBean> ,SessionAware,RequestAware{
	
	private static final long serialVersionUID = 6042178570912513922L;
	private int rowsPerPage =5; 
	private Map<String,Object> session;
	private Map<String, Object> request;
	private PageBean pages = new PageBean();
	private BookBean book = new BookBean();
	@Resource(name ="bookService")
	private BookService bookServ;

	public String toadd(){
		return "success";
	}
	
	public String toupdate(){
		Long id = (Long)request.get("id");
		BookBean tBook=bookServ.load(id);
		session.put("book", tBook);
		return "success";
	}
	public String update(){	
		bookServ.update(book);	
		session.put("msg", "书籍更新成功");
		return "success";
	}
	public String deleteGoods(){		
		Long id = (Long)request.get("id");
		bookServ.delete(id);
		return "success";
	}
	public String addGoods(){
		bookServ.create(book);
		session.put("msg", "添加书籍成功");
		return "success";
	}
	public String goodsList(){		

		pages.setRowsPerPage(rowsPerPage);
		System.out.println("接受pages参数"+pages.getPageNum());
		List<BookBean> bookList = bookServ.look(pages);
		session.put("bookList", bookList);
		return "success";
	}
	@Override
	public BookBean getModel() {
		return book;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session=session;
	}

	@Override
	public void setRequest(Map<String, Object> request) {
		this.request=request;
		
	}

	public int getRowsPerPage() {
		return rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public PageBean getPages() {
		return pages;
	}

	public void setPages(PageBean pages) {
		this.pages = pages;
	}
	
}
