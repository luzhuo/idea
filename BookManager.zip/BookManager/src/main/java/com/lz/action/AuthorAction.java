package com.lz.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.lz.domian.PageBean;
import com.lz.entity.AuthorBean;
import com.lz.service.AuthorService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@Controller("authorAction")
@Scope("prototype")
public class AuthorAction extends ActionSupport implements ModelDriven<AuthorBean> ,SessionAware,RequestAware{
	private static final long serialVersionUID = 6042178570912513922L;
	private int rowsPerPage =5; 
	private PageBean pages = new PageBean();
	private Map<String,Object> session;
	private Map<String, Object> request;
	private  AuthorBean author = new AuthorBean();
	@Resource(name ="authorService")
	private AuthorService authorServ;

	public String toadd(){
		return "success";
	}
	
	public String toupdate(){
		Long id = (Long)request.get("id");
		AuthorBean load = authorServ.load(id);
		session.put("author", load);
		return "success";
	}
	public String update(){	
		
		authorServ.update(author);	
		session.put("msg", "作者更新成功");
		return "success";
	}
	public String delete(){		
		Long id = (Long)request.get("id");
		authorServ.delete(id);
		return "success";
	}
	public String add(){
		authorServ.create(author);
		session.put("msg", "添加作者成功");
		return "success";
	}
	public String list(){	
		pages.setRowsPerPage(rowsPerPage);
		List<AuthorBean> authorList = authorServ.look(pages);
		session.put("authorList", authorList);
		return "success";
	}
	@Override
	public AuthorBean getModel() {
		return author;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session=session;
	}

	@Override
	public void setRequest(Map<String, Object> request) {
		this.request=request;
		
	}

	public int getRowsPerPage() {
		return rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public PageBean getPages() {
		return pages;
	}

	public void setPages(PageBean pages) {
		this.pages = pages;
	}
	
}
