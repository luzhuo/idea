package com.lz.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;

@Controller("loginAction")
@Scope("prototype")
public class LoginAction extends ActionSupport implements SessionAware{
	private static final long serialVersionUID = 6764271070607514442L;
	private Map<String,Object> session;
	private String username;
	private String password;
	public String login(){
		System.out.println("user:"+username);
		System.out.println("password:"+password);
		if("111".equals(username)&& "222".equals(password)){
			return "success";
		}else{
			session.put("msg", "用户名或者密码错误");
			return "input";
		}
		
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		this.session=session;
		
	}
	
	
}
