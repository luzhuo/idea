package com.lz.domian;

import java.io.Serializable;

public class PageBean implements Serializable{

	private static final long serialVersionUID = -6370137757534629093L;
	private int pageNum;
	private int rowsNum;
	private int rowsPerPage = 15;
	private int maxPage;

	public int getLastPage() {
		if (pageNum > 1)
			return pageNum - 1;
		return 0;
	}

	public int getNextPage() {
		if (pageNum < maxPage)
			return pageNum + 1;
		return 0;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getRowsNum() {
		return rowsNum;
	}

	public void setRowsNum(int rowsNum) {
		this.rowsNum = rowsNum;
	}

	public int getRowsPerPage() {
		return rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public int getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}

}
