package com.lz.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lz.entity.AuthorBean;
@Repository("authorDao")
public class AuthorDaoImpl extends BaseDaoImpl<AuthorBean, Long> implements IAuthorDao {

	@Override
	public List<AuthorBean> Find(AuthorBean up) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
