package com.lz.dao;

import java.io.Serializable;
import java.util.List;

public interface IBaseDao<T extends Serializable, ID extends Serializable> {
	T save(T record);

	T delete(T id);

	T load(ID id);

	T update(T record);

	List<T> selectByExample(T record, int... pages);

	int selectByExampleRowsNum(T record);
	
	public List<T> Find(T up)throws Exception;
}
