package com.lz.dao;

import com.lz.entity.BookBean;

public interface IBookDao extends IBaseDao<BookBean, Long> {

}
