package com.lz.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Projections;
import org.springframework.transaction.annotation.Transactional;
@Transactional
public abstract class BaseDaoImpl<T extends Serializable, ID extends Serializable>
		implements IBaseDao<T, ID> {
	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;
	private Class<T> persistClass;

	@SuppressWarnings("unchecked")
	public BaseDaoImpl() {
		this.persistClass = (Class<T>) (((ParameterizedType) getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0]);
	}

	@Override
	public T save(T record) {
		this.getSession().save(record);
		return record;
	}

	@Override
	public T delete(T record) {
		this.getSession().delete(record);
		return record;
	}
	@SuppressWarnings("unchecked")
	@Override
	public T load(ID id) {
		return (T) this.getSession().get(persistClass, id);
	}	

	@Override
	public T update(T record) {
		this.getSession().update(record);
		return record;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> selectByExample(T record, int... pages) {
		Criteria c = this.getSession().createCriteria(persistClass);
		if (record != null)
			c.add(Example.create(record).enableLike());
		if (pages != null && pages.length > 0)
			c.setFirstResult(pages[0]);
		if (pages != null && pages.length > 1)
			c.setMaxResults(pages[1]);
		return c.list();
	}

	@Override
	public int selectByExampleRowsNum(T record) {
		Criteria c = this.getSession().createCriteria(persistClass);
		if (record != null)
			c.add(Example.create(record).enableLike());
		c.setProjection(Projections.rowCount());
		return ((Number) c.uniqueResult()).intValue();
	}

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}
	
	
	
}
