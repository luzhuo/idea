package com.lz.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.lz.entity.BookBean;

@Repository("bookDao")
public class BookDaoImpl extends BaseDaoImpl<BookBean, Long> implements IBookDao {

	@Override
	public List<BookBean> Find(BookBean book) throws Exception {
		Session session = super.getSession();
		StringBuffer hql = new StringBuffer("from t_books where 1=1 ");
		if(book.getTitle()!=null){
			hql.append("and title = :title");
		}
		if(book.getPress()!=null){
			hql.append("and press= :press");
		}
		if(book.getAuthor()!=null){
			hql.append("and author= :author");
		}		  
		Query query = session.createQuery(hql.toString());
		query.setProperties(book);
		List<BookBean> list = query.list();
		return list;
	}

}
