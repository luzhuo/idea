package com.lz.dao;

import com.lz.entity.AuthorBean;

public interface IAuthorDao extends IBaseDao<AuthorBean, Long> {

}
