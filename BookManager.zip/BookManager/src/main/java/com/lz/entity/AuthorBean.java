package com.lz.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity(name = "t_authors")
@SequenceGenerator(name = "seq12", sequenceName = "seq_author", initialValue = 1)
public class AuthorBean implements Serializable{
	private static final long serialVersionUID = 3188837045527953699L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq12")
	private Long id;
	@Column(length = 10,nullable = false)
	private String name;
	@Column(length = 30)
	private String address;
	@Column(columnDefinition = "number(3)")
	private int age;
	@Column(columnDefinition = "number(1) default 1")
	private Boolean sex;	
	@Column(length = 300)
	private String info;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Boolean getSex() {
		return sex;
	}
	public void setSex(Boolean sex) {
		this.sex = sex;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
	//防出错getset
	public Long getid() {
		return id;
	}
	public void setid(Long id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public int getage() {
		return age;
	}
	public void setage(int age) {
		this.age = age;
	}
	public Boolean getsex() {
		return sex;
	}
	public void setsex(Boolean sex) {
		this.sex = sex;
	}
	public String getinfo() {
		return info;
	}
	public void setinfo(String info) {
		this.info = info;
	}
	

}
