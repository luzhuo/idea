package com.lz.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity(name = "t_books")
@SequenceGenerator(name = "seq11", sequenceName = "seq_book", initialValue = 1)
public class BookBean implements Serializable{
	private static final long serialVersionUID = 1898149432218271215L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq11")
	private Long id;
	@Column(length = 10,nullable = false)
	private String title;
	@Column(length = 10,nullable = false)
	private String author;
	@Column(columnDefinition = "number(8,2) default 0")
	private double price;
	@Column(length = 10,nullable = false)
	private String press;
	@Temporal(TemporalType.DATE)
	@Column(columnDefinition = "date default sysdate")
	private Date publicationDate;
	@Column(length = 200)
	private String info;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public Date getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
	//防出错 getset
	public Long getid() {
		return id;
	}
	public void setid(Long id) {
		this.id = id;
	}
	public String gettitle() {
		return title;
	}
	public void settitle(String title) {
		this.title = title;
	}
	public String getauthor() {
		return author;
	}
	public void setauthor(String author) {
		this.author = author;
	}
	public double getprice() {
		return price;
	}
	public void setprice(double price) {
		this.price = price;
	}
	public String getpress() {
		return press;
	}
	public void setpress(String press) {
		this.press = press;
	}
	public Date getpublicationDate() {
		return publicationDate;
	}
	public void setpublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}
	public String getinfo() {
		return info;
	}
	public void setinfo(String info) {
		this.info = info;
	}
	
}
