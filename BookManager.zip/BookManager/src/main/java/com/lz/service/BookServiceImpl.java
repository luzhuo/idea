package com.lz.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lz.dao.IBookDao;
import com.lz.domian.PageBean;
import com.lz.entity.BookBean;

@Service("bookService")
@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
public class BookServiceImpl implements BookService {
	@Resource(name = "bookDao")
	private IBookDao bookDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void create(BookBean book) {
		bookDao.save(book);
	}

	@Override
		public List<BookBean> look(PageBean pages) {	
			if (pages != null && pages.getRowsPerPage() > 0) {
				if (pages.getPageNum() < 1)
					pages.setPageNum(1);
				if (pages.getMaxPage() < 1) {
					int rowsNum = bookDao.selectByExampleRowsNum(null);
					if (rowsNum < 1)
						return null;
					int maxPage = (rowsNum - 1 + pages.getRowsPerPage())
							/ pages.getRowsPerPage();
					pages.setMaxPage(maxPage);
					pages.setRowsNum(rowsNum);
				}
			}
			if (pages.getPageNum() > pages.getMaxPage())
				pages.setPageNum(pages.getMaxPage());
			int begin = (pages.getPageNum() - 1) * pages.getRowsPerPage();
			return bookDao.selectByExample(null,begin, pages.getRowsPerPage());
		}

	@Override
	public void update(BookBean book) {
		bookDao.update(book);

	}

	@Override
	public void delete(Long id) {
		BookBean book = bookDao.load(id);
		bookDao.delete(book);
	}

	@Override
	public BookBean load(Long id) {

		return bookDao.load(id);
	}

	@Override
	public List<BookBean> find(BookBean book) throws Exception {

		return bookDao.Find(book);
	}

}
