package com.lz.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lz.dao.IAuthorDao;
import com.lz.domian.PageBean;
import com.lz.entity.AuthorBean;

@Service("authorService")
@Transactional(readOnly=true,propagation=Propagation.SUPPORTS)
public class AuthorServiceImpl implements AuthorService{
		@Resource(name="authorDao")
		private IAuthorDao authorDao;
		
		@Override
		@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
		public void create(AuthorBean author) {
			authorDao.save(author);
		}

		@Override
		public List<AuthorBean> look(PageBean pages) {
			if (pages != null && pages.getRowsPerPage() > 0) {
				if (pages.getPageNum() < 1)
					pages.setPageNum(1);
				if (pages.getMaxPage() < 1) {
					int rowsNum = authorDao.selectByExampleRowsNum(null);
					if (rowsNum < 1)
						return null;
					int maxPage = (rowsNum - 1 + pages.getRowsPerPage())
							/ pages.getRowsPerPage();
					pages.setMaxPage(maxPage);
					pages.setRowsNum(rowsNum);
				}
			}
			if (pages.getPageNum() > pages.getMaxPage())
				pages.setPageNum(pages.getMaxPage());
			int begin = (pages.getPageNum() - 1) * pages.getRowsPerPage();
			return authorDao.selectByExample(null,begin, pages.getRowsPerPage());
		}

		@Override
		public void update(AuthorBean Author) {
			authorDao.update(Author);
			
		}

		@Override
		public void delete(Long id) {		
			AuthorBean author = authorDao.load(id);
			authorDao.delete(author);
		}

		
		
		@Override
		public AuthorBean load(Long id) {					
			return authorDao.load(id);
		}
}
