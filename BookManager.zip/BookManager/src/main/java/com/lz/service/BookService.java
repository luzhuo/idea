package com.lz.service;

import java.util.List;

import com.lz.domian.PageBean;
import com.lz.entity.BookBean;

public interface BookService{

	List<BookBean> look(PageBean pages);

	void create(BookBean book);
	
	void update(BookBean book);

	void delete(Long id);
	
	BookBean load(Long id);

	List<BookBean> find(BookBean book) throws Exception;
	
}
