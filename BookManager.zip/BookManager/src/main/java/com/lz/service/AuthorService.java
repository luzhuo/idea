package com.lz.service;

import java.util.List;

import com.lz.domian.PageBean;
import com.lz.entity.AuthorBean;

public interface AuthorService{

	List<AuthorBean> look(PageBean pages);

	void create(AuthorBean Author);
	
	void update(AuthorBean Author);

	void delete(Long id);
	
	AuthorBean load(Long id);


}
