// JavaScript Document
$(document).ready(function(){
	$("#c>li").each(function(){
		$("#c>li").css("display:none");				 
	});				   
	
});